class Name():
    def __init__(self, customer_name):
        self.customer_name = customer_name