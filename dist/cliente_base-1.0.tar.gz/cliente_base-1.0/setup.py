from setuptools import setup

setup(
    name = "cliente_base",
    version = "1.0",
    description = "Primer Paquete del Proyecto",
    author = "Agustin Caceres",
    author_email = "agustinn_caceress@gmail.com",
    packages = ['cliente_base']
)